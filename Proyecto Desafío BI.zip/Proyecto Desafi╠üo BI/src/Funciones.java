import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
/**
* Clase que contiene la función para entregar una cantidad aleatoria de días
* feriados dependiendo de la cantidad ingresada por el usuario y la función que en base a un
*  listado de días feriados calcula la cantidad de días que debemos trabajar 
*  en un año
* @author lilianacisternasjara
*
*/
public class Funciones {
	public static void main(String[] args) {
		calculoDias();//Se llama solo a la segunda función porque ella contiene a la primera
	}
	/**
	 * Función que retorna las fechas feriadas dependiendo
	 * la cantidad ingresada por el usuario
	 * @return 
	 */
	public static ArrayList<Integer> feriados() {
		Scanner leer = new Scanner(System.in);
		Random rand = new Random();
		int numFeriados;
		ArrayList<Integer> fechasFeriadas = new ArrayList<Integer>();
		System.out.println("Ingrese la cantidad de feriados que desea generar:");
		numFeriados= leer.nextInt(); 
		for (int i=0; i<numFeriados; i++) {
			int intRandom = rand.nextInt(365) + 1;
			fechasFeriadas.add(intRandom);
		}
		System.out.println(fechasFeriadas);
		return fechasFeriadas;
	}
	/**
	 * Función que calcula los días laborales en base al listado de días feriados 
	 * entregados por la función anterior 
	 */
	public static void calculoDias() {
		int feriadosValidos = 0;
		int diasDeSemana = 260;//260 días que son de lunes a viernes
		int diasLaborales = 0;
		ArrayList<Integer> fechasFeriadas = feriados();//Se ocupa la función anterior para crear el ArraListy
		for (int i=0; i<fechasFeriadas.size(); i++) {
			if(fechasFeriadas.get(i)!=1 && fechasFeriadas.get(i)%7!=0 && fechasFeriadas.get(i)%7!=1) {
				feriadosValidos++;
			}
			diasLaborales = diasDeSemana - feriadosValidos;
		}
		System.out.println("Dias Laborales del año 2023: " + diasLaborales);
	}
}